from django.contrib import admin

from .models import enter

admin.site.register(enter)

