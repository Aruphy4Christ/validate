from django.http import HttpResponse
from django.shortcuts import render
import operator

def index(request):
	return HttpResponse("the  eififjo")   