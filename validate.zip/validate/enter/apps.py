from django.apps import AppConfig


class EnterConfig(AppConfig):
    name = 'enter'
