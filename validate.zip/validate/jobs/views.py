from django.shortcuts import render
from .models import Job

def home(request):
	return render(request, 'jobs/home.html')
	
def portfolio(request):
	Job = Job.objects 	
	return render(request, 'jobs/portfolio.html', {'jobs':job})
